﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProjetoScania2.DataAccess;
using ProjetoScania2.Models;
using ProjetoScania2.ViewModels;
using System.Diagnostics;
using System.Runtime.Intrinsics.X86;

namespace ProjetoScania2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InscricoesController : ControllerBase
    {
        InscricaoDao inscricaoDao;
        InscricaoVagaDao inscricaoVagaDao;

        public InscricoesController()
        {
            inscricaoDao = new InscricaoDao();
            inscricaoVagaDao = new InscricaoVagaDao();
        }

        //Lista de inscrições existentes no banco de dados! ok, está retornando.
        [HttpGet]
        public IEnumerable<ListarVagaECandidatoVM> GetInscricao()
        {
            return inscricaoDao.ListarTodos();
        }


        //Lista de inscrições por id! OK, está retornando.               
        [HttpGet("{id}")]
        public ListarVagaECandidatoVM GetInscricao(int id)
        {
            return inscricaoDao.Buscar(id);
        }

        //Busca as vagas que o candidato se inscreveu pelo id do candidato

        //inserir um unico candidato em
        //mais de uma vaga para ver se está função está funcionando
        [HttpGet("candidatovaga/{idcandidato}")]
        public IEnumerable<ListarVagaECandidatoVM> GetCandidatoVaga(int idcandidato)
        {
            return inscricaoVagaDao.BuscarCandidato(idcandidato);
        }


        //Busca os candidatos que a vaga recebeu pelo id da vaga - testar mais inserts para
        //verificar se em uma empresa tem mais candidatura para a mesma vaga, não consegui inserir no banco e na api
        [HttpGet("vagacandidato/{idvaga}")]
        public IEnumerable<ListarVagaECandidatoVM> GetVagaCandidato(int idvaga)
        {
            return inscricaoVagaDao.BuscarVaga(idvaga);
        }

        //Realiza a inscrição do candidato na vaga 
        // não está incluindo por causa da duplicate key value violates unique constraint "pk_inscricao_candidato".Não sei como resolver kkk
        [HttpPost]
        [Route("IncluirInscricao")]
        public InscricoesVaga? PostInscricao(InscricoesVaga inscricao)
        {
            return inscricaoDao.Incluir(inscricao);
        }


        //Deleta a inscrição do candidato a vaga por id // OK, está removendo. 
        [HttpDelete("Remover/{id}")]
        
        public bool DeleteInscricao(int id)
        {
            return inscricaoDao.Remover(id);
        }

    }
}
