﻿namespace ProjetoScania2.ViewModels
{
    public class ListarVagaECandidatoVM
    {
        public int id { get; set; }
        public int idcandidato { get; set; }
        public int idvaga { get; set; }
        public string? nomeempresa { get; set; }
        public string? titulo_vaga { get; set; }
        public string? nomecandidato { get; set; }
        public string? datainscricao { get; set; }
    }
}
