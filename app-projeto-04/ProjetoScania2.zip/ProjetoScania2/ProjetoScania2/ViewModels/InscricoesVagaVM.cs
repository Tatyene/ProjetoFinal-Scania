﻿namespace ProjetoScania2.ViewModels
{
    public class InscricoesVagaVM
    {
        public int id { get; set; }
        public int idcandidato { get; set; }
        public int idvaga { get; set; }
        public string? datainscricao { get; set; }
    }
}
