﻿namespace ProjetoScania2.Models
{
    public class CandidatoEmpresa
    {
        public int id { get; set; }
        public string? nome { get; set; }
    }
}
