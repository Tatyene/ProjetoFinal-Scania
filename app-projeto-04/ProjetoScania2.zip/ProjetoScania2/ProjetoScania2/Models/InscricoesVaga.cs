﻿namespace ProjetoScania2.Models
{
    public class InscricoesVaga
    {
        public int id { get; set; }
        public int idcandidato { get; set; }
        public int idvaga { get; set; }
        public DateTime datainscricao { get; set; }
    }
}
